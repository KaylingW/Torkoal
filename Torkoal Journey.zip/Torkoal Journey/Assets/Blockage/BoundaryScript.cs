﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoundaryScript : MonoBehaviour {

	// Use this for initialization
	void cantExit(Collider myCollider)
    {

    }
}
